
import { Pilgrim } from '@/context/AppContext';

// Define enhanced pilgrim type with additional properties
export type EnhancedPilgrim = Pilgrim & {
  groupName: string;
  roomTypeFormatted: string;
};
