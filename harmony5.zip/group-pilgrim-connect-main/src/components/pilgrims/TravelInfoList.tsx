
import React, { useState, useEffect, useMemo } from 'react';
import { useAppContext } from '@/context/AppContext';
import { useDebounce } from '@/hooks/use-debounce';
import { useVirtualizer } from '@tanstack/react-virtual';
import { Table, TableBody } from "@/components/ui/table";
import { EnhancedPilgrim } from '@/types/pilgrim';
import { TravelInfoSearch } from './TravelInfoSearch';
import { TravelInfoTableHeader } from './TravelInfoTableHeader';
import { TravelInfoTableRow } from './TravelInfoTableRow';
import { TravelInfoSkeleton } from './TravelInfoSkeleton';
import { 
  getPilgrimsWithTravel, 
  getGroupName, 
  formatRoomType, 
  enhancePilgrims,
  getFilteredPilgrims 
} from '@/utils/pilgrimUtils';
import { createExcelWorker, exportToExcel } from '@/utils/excelExport';

export const TravelInfoList: React.FC = () => {
  const { pilgrims, groups, language } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [filteredPilgrims, setFilteredPilgrims] = useState<EnhancedPilgrim[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [page, setPage] = useState(1);
  const itemsPerPage = 50;
  
  // Create a container ref for the virtual list
  const parentRef = React.useRef<HTMLDivElement>(null);
  
  // Pre-process the pilgrim data with travel information
  const pilgrimsWithTravel = useMemo(() => 
    getPilgrimsWithTravel(pilgrims), [pilgrims]
  );
  
  // Get group name by ID - memoized
  const getGroupNameFn = useMemo(() => 
    (groupId: number) => getGroupName(groupId, groups, language), 
    [groups, language]
  );
  
  // Format room type - memoized
  const formatRoomTypeFn = useMemo(() => 
    (roomType: string) => formatRoomType(roomType, language), 
    [language]
  );
  
  // Enhanced pilgrims data with proper formatting
  const enhancedPilgrims = useMemo(() => 
    enhancePilgrims(pilgrimsWithTravel, getGroupNameFn, formatRoomTypeFn),
    [pilgrimsWithTravel, getGroupNameFn, formatRoomTypeFn]
  );
  
  // Apply search filter with debouncing
  useEffect(() => {
    setIsLoading(true);
    
    // Use setTimeout to prevent blocking the main thread
    const timer = setTimeout(() => {
      try {
        const filtered = getFilteredPilgrims(
          pilgrims, 
          debouncedSearchTerm, 
          enhancedPilgrims
        );
        setFilteredPilgrims(filtered);
      } finally {
        setIsLoading(false);
      }
    }, 100);
    
    return () => clearTimeout(timer);
  }, [debouncedSearchTerm, enhancedPilgrims, pilgrims]);
  
  // Setup virtualizer
  const rowVirtualizer = useVirtualizer({
    count: filteredPilgrims.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 60, // estimated row height
    overscan: 5, // number of items to render before and after visible area
  });
  
  // Export travel information to Excel using a Web Worker
  const handleExportToExcel = () => {
    if (isExporting || filteredPilgrims.length === 0) return;
    
    setIsExporting(true);
    
    // If the browser supports Web Workers
    if (window.Worker) {
      try {
        const worker = createExcelWorker();
        
        if (worker) {
          worker.onmessage = function(e) {
            const { formattedData } = e.data;
            
            // Create and download the Excel file
            const XLSX = require('xlsx');
            const worksheet = XLSX.utils.json_to_sheet(formattedData);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Travel Information");
            
            const date = new Date();
            const fileName = `travel_information_${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}.xlsx`;
            
            XLSX.writeFile(workbook, fileName);
            
            worker.terminate();
            setIsExporting(false);
          };
          
          worker.onerror = function() {
            worker.terminate();
            exportToExcel(filteredPilgrims, language, setIsExporting);
          };
          
          worker.postMessage({ data: filteredPilgrims, language });
        } else {
          exportToExcel(filteredPilgrims, language, setIsExporting);
        }
      } catch (error) {
        console.error('Worker error:', error);
        exportToExcel(filteredPilgrims, language, setIsExporting);
      }
    } else {
      exportToExcel(filteredPilgrims, language, setIsExporting);
    }
  };
  
  // Render loading skeleton
  if (isLoading && page === 1) {
    return <TravelInfoSkeleton />;
  }
  
  return (
    <div className="space-y-4">
      <TravelInfoSearch 
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        exportToExcel={handleExportToExcel}
        isExporting={isExporting}
        isLoading={isLoading}
        hasData={filteredPilgrims.length > 0}
        language={language}
      />
      
      <div className="rounded-md border glass-card">
        <TravelInfoTableHeader language={language} />
        
        {filteredPilgrims.length > 0 ? (
          <div 
            ref={parentRef} 
            className="overflow-auto" 
            style={{ height: '500px', maxHeight: '70vh' }}
          >
            <Table>
              <TableBody 
                style={{
                  height: `${rowVirtualizer.getTotalSize()}px`,
                  width: '100%',
                  position: 'relative',
                }}
              >
                {rowVirtualizer.getVirtualItems().map(virtualRow => (
                  <TravelInfoTableRow
                    key={filteredPilgrims[virtualRow.index].id}
                    pilgrim={filteredPilgrims[virtualRow.index]}
                    language={language}
                    style={{
                      height: `${virtualRow.size}px`,
                      transform: `translateY(${virtualRow.start}px)`,
                    }}
                  />
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="p-4 text-center text-muted-foreground">
            {language === 'en' 
              ? searchTerm 
                ? 'No travel information found' 
                : 'No travel information available'
              : searchTerm
                ? 'لم يتم العثور على معلومات سفر'
                : 'لا توجد معلومات سفر متاحة'
            }
          </div>
        )}
      </div>
    </div>
  );
};

export default TravelInfoList;
