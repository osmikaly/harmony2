import React, { useState } from 'react';
import { useAppContext } from '@/context/AppContext';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Download, PenSquare, Plus, Search, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import * as XLSX from 'xlsx';

export const PilgrimList: React.FC = () => {
  const {
    pilgrims,
    groups,
    deletePilgrim,
    language
  } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredPilgrims = pilgrims.filter(pilgrim => 
    pilgrim.nameEn.toLowerCase().includes(searchTerm.toLowerCase()) || 
    pilgrim.nameAr.toLowerCase().includes(searchTerm.toLowerCase()) || 
    pilgrim.passportNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
    pilgrim.id.toString().includes(searchTerm)
  );
  
  const handleDelete = (id: number) => {
    deletePilgrim(id);
    toast.success(language === 'en' ? 'Pilgrim deleted successfully' : 'تم حذف الحاج بنجاح');
  };
  
  const getGroupName = (groupId: number) => {
    const group = groups.find(g => g.id === groupId);
    return group ? group.name : '-';
  };
  
  const formatDate = (dateString: string) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(date);
  };
  
  const calculateAge = (birthDate: string) => {
    if (!birthDate) return '-';
    const today = new Date();
    const birthDateObj = new Date(birthDate);
    let age = today.getFullYear() - birthDateObj.getFullYear();
    const monthDiff = today.getMonth() - birthDateObj.getMonth();
    if (monthDiff < 0 || monthDiff === 0 && today.getDate() < birthDateObj.getDate()) {
      age--;
    }
    return age;
  };
  
  const exportToExcel = () => {
    const dataToExport = filteredPilgrims.map(pilgrim => ({
      ID: pilgrim.id,
      'Latin Name': pilgrim.nameEn,
      'Arabic Name': pilgrim.nameAr,
      'Group': getGroupName(pilgrim.groupId),
      'Profession': pilgrim.profession || '-',
      'Passport Number': pilgrim.passportNumber,
      'Gender': pilgrim.gender === 'male' ? (language === 'en' ? 'Male' : 'ذكر') : (language === 'en' ? 'Female' : 'أنثى'),
      'Birth Date': formatDate(pilgrim.birthDate),
      'Age': calculateAge(pilgrim.birthDate),
      'Status': pilgrim.status === 'active' ? (language === 'en' ? 'Active' : 'نشط') : (language === 'en' ? 'Inactive' : 'غير نشط'),
      'Has Visa': pilgrim.hasVisa ? (language === 'en' ? 'Yes' : 'نعم') : (language === 'en' ? 'No' : 'لا')
    }));
    
    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Pilgrims");
    
    // Generate file name with date
    const date = new Date();
    const fileName = `pilgrims_${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}.xlsx`;
    
    XLSX.writeFile(workbook, fileName);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="relative w-full sm:w-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground rtl:left-auto rtl:right-3" />
          <Input placeholder={language === 'en' ? 'Search pilgrims...' : 'البحث عن حاج...'} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-9 rtl:pl-4 rtl:pr-9 w-full sm:w-[300px]" />
        </div>
        <div className="flex gap-2 justify-end w-full sm:w-auto">
          <Button onClick={exportToExcel} variant="outline" size="sm" className="h-9">
            <Download className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />
            {language === 'en' ? 'Export' : 'تصدير'}
          </Button>
          <Button asChild size="sm" className="h-9">
            <Link to="/pilgrims/new">
              <Plus className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />
              {language === 'en' ? 'New Pilgrim' : 'حاج جديد'}
            </Link>
          </Button>
        </div>
      </div>
      
      <div className="overflow-auto rounded-md border glass-card">
        <table className="w-full caption-bottom text-sm">
          <thead className="border-b">
            <tr className="bg-muted/50">
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'ID' : 'رقم الحاج'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Latin Name' : 'الاسم باللاتينية'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Arabic Name' : 'الاسم بالعربية'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Group' : 'المجموعة'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Profession' : 'المهنة'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Passport' : 'رقم جواز السفر'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Gender' : 'الجنس'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Birth Date' : 'تاريخ الميلاد'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Age' : 'العمر'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Status' : 'الحالة'}
              </th>
              <th className="h-12 px-4 text-left align-middle font-medium">
                {language === 'en' ? 'Actions' : 'الإجراءات'}
              </th>
            </tr>
          </thead>
          <tbody>
            {filteredPilgrims.length > 0 ? filteredPilgrims.map(pilgrim => <tr key={pilgrim.id} className="border-b transition-colors hover:bg-muted/50">
                  <td className="p-4 align-middle font-medium">{pilgrim.id}</td>
                  <td className="p-4 align-middle">{pilgrim.nameEn || '-'}</td>
                  <td className="p-4 align-middle">{pilgrim.nameAr || '-'}</td>
                  <td className="p-4 align-middle">{getGroupName(pilgrim.groupId)}</td>
                  <td className="p-4 align-middle">{pilgrim.profession || '-'}</td>
                  <td className="p-4 align-middle">{pilgrim.passportNumber || '-'}</td>
                  <td className="p-4 align-middle">
                    {language === 'en' ? pilgrim.gender === 'male' ? 'Male' : 'Female' : pilgrim.gender === 'male' ? 'ذكر' : 'أنثى'}
                  </td>
                  <td className="p-4 align-middle">{formatDate(pilgrim.birthDate)}</td>
                  <td className="p-4 align-middle">{calculateAge(pilgrim.birthDate)}</td>
                  <td className="p-4 align-middle">
                    <Badge variant="outline" className={`${pilgrim.status === 'active' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                      {language === 'en' ? pilgrim.status === 'active' ? 'Active' : 'Inactive' : pilgrim.status === 'active' ? 'نشط' : 'غير نشط'}
                    </Badge>
                  </td>
                  <td className="p-4 align-middle">
                    <div className="flex space-x-2 rtl:space-x-reverse">
                      <Button asChild variant="ghost" size="icon" className="h-8 w-8">
                        <Link to={`/pilgrims/${pilgrim.id}`}>
                          <PenSquare className="h-4 w-4" />
                          <span className="sr-only">Edit</span>
                        </Link>
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleDelete(pilgrim.id)}>
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </td>
                </tr>) : <tr>
                <td colSpan={11} className="p-4 text-center text-muted-foreground">
                  {language === 'en' ? searchTerm ? 'No pilgrims found' : 'No pilgrims available' : searchTerm ? 'لم يتم العثور على حجاج' : 'لا يوجد حجاج متاحين'}
                </td>
              </tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
};
