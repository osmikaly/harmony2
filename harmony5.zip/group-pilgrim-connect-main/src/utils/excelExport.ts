
import * as XLSX from 'xlsx';
import { EnhancedPilgrim } from '@/types/pilgrim';

// Create a Web Worker wrapper for Excel export
export const createExcelWorker = () => {
  if (typeof window === 'undefined') return null;
  
  const workerCode = `
    self.onmessage = function(e) {
      const { data, language } = e.data;
      
      // Convert the data for Excel format
      const formattedData = data.map(item => ({
        ID: item.id,
        'Latin Name': item.nameEn || '',
        'Arabic Name': item.nameAr || '',
        'Group': item.groupName,
        'Passport Number': item.passportNumber || '',
        'Airline': item.airline || '',
        'Has Visa': item.hasVisa === true ? (language === 'en' ? 'Yes' : 'نعم') : (language === 'en' ? 'No' : 'لا'),
        'Room Type': item.roomTypeFormatted
      }));
      
      self.postMessage({ formattedData });
    };
  `;
  
  const blob = new Blob([workerCode], { type: 'application/javascript' });
  return new Worker(URL.createObjectURL(blob));
};

// Fallback export method if Web Workers are not supported
export const exportToExcel = (
  data: EnhancedPilgrim[], 
  language: 'en' | 'ar',
  setIsExporting: (value: boolean) => void
) => {
  try {
    setTimeout(() => {
      try {
        const dataToExport = data.map(pilgrim => ({
          ID: pilgrim.id,
          'Latin Name': pilgrim.nameEn || '',
          'Arabic Name': pilgrim.nameAr || '',
          'Group': pilgrim.groupName,
          'Passport Number': pilgrim.passportNumber || '',
          'Airline': pilgrim.airline || '',
          'Has Visa': pilgrim.hasVisa === true ? (language === 'en' ? 'Yes' : 'نعم') : (language === 'en' ? 'No' : 'لا'),
          'Room Type': pilgrim.roomTypeFormatted
        }));
        
        const worksheet = XLSX.utils.json_to_sheet(dataToExport);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Travel Information");
        
        const date = new Date();
        const fileName = `travel_information_${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}.xlsx`;
        
        XLSX.writeFile(workbook, fileName);
      } finally {
        setIsExporting(false);
      }
    }, 100);
  } catch (error) {
    console.error('Excel export error:', error);
    setIsExporting(false);
  }
};
